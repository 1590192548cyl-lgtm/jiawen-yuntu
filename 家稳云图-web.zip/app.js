const AGENT_API_URL = "";

const state = {
  hasProfile: false,
  currentView: "welcome",
  history: [],
  profile: {
    income: 28000,
    expenses: 12500,
    debt: 6500,
    emergency: 4,
    incomeStability: "stable",
    protection: "basic",
    responsibility: "moderate",
    goal: "buffer"
  },
  score: null,
  report: null
};

const labels = {
  protection: {
    full: "较完整",
    basic: "基础",
    weak: "不足",
    none: "缺口明显"
  },
  goal: {
    buffer: "建立风险缓冲",
    debt: "优化债务压力",
    education: "教育金储备",
    pension: "养老金规划",
    wealth: "稳健财富积累"
  }
};

function clamp(value, min, max) {
  return Math.min(Math.max(value, min), max);
}

function ratio(numerator, denominator) {
  if (!denominator || denominator <= 0) return 0;
  return numerator / denominator;
}

function calculateRisk(profile) {
  const incomeScore = {
    stable: 16,
    normal: 12,
    unstable: 7,
    fragile: 4
  }[profile.incomeStability];

  const spendingRate = ratio(profile.expenses, profile.income);
  const debtRate = ratio(profile.debt, profile.income);
  const savingRate = ratio(profile.income - profile.expenses - profile.debt, profile.income);

  const spendingScore = clamp(18 - spendingRate * 24, 2, 18);
  const debtScore = clamp(18 - debtRate * 36, 2, 18);
  const emergencyScore = clamp(profile.emergency / 6 * 18, 1, 18);
  const protectionScore = {
    full: 16,
    basic: 11,
    weak: 7,
    none: 3
  }[profile.protection];
  const responsibilityScore = {
    light: 16,
    moderate: 12,
    heavy: 8,
    critical: 4
  }[profile.responsibility];

  const rawScore = incomeScore + spendingScore + debtScore + emergencyScore + protectionScore + responsibilityScore;
  const score = Math.round(clamp(rawScore, 0, 100));
  const level = score >= 85 ? "健康稳健" : score >= 70 ? "稳健关注" : score >= 55 ? "结构承压" : "高风险预警";
  const tone = score >= 70 ? "good" : score >= 55 ? "warn" : "danger";

  const weaknesses = [];
  if (profile.incomeStability === "unstable" || profile.incomeStability === "fragile") {
    weaknesses.push("收入稳定性不足，需要避免把长期支出建立在短期收入预期上。");
  }
  if (spendingRate > 0.55) {
    weaknesses.push("刚性支出占收入比例偏高，月度现金流弹性不足。");
  }
  if (debtRate > 0.35) {
    weaknesses.push("债务收入比偏高，建议优先梳理月供与还款节奏。");
  }
  if (profile.emergency < 3) {
    weaknesses.push("应急金覆盖不足三个月，面对失业或突发支出时缓冲偏薄。");
  }
  if (profile.protection === "weak" || profile.protection === "none") {
    weaknesses.push("基础保障存在缺口，疾病或意外风险可能放大家庭现金流压力。");
  }
  if (profile.responsibility === "heavy" || profile.responsibility === "critical") {
    weaknesses.push("家庭责任叠加明显，需要把育儿、赡养和住房压力放进同一张预算表。");
  }
  if (!weaknesses.length) {
    weaknesses.push("当前结构整体平衡，建议继续维持月度复盘和风险预警习惯。");
  }

  return {
    score,
    level,
    tone,
    spendingRate,
    debtRate,
    savingRate,
    weaknesses
  };
}

function getBufferPlan(profile, score) {
  const liquidityStatus = profile.emergency >= 6 ? "ok" : profile.emergency >= 3 ? "watch" : "risk";
  const debtStatus = score.debtRate <= 0.25 ? "ok" : score.debtRate <= 0.35 ? "watch" : "risk";
  const familyStatus = profile.responsibility === "light" || profile.responsibility === "moderate" ? "ok" : "watch";
  const hedgeStatus = profile.protection === "full" ? "ok" : profile.protection === "basic" ? "watch" : "risk";

  return [
    {
      title: "流动性缓冲层",
      status: liquidityStatus,
      text: profile.emergency >= 6
        ? "应急金覆盖已经达到稳健区间，继续保持高流动性资产独立存放。"
        : "优先把应急金补足至3-6个月刚性支出，先稳住家庭现金流底线。"
    },
    {
      title: "债务安全层",
      status: debtStatus,
      text: score.debtRate <= 0.35
        ? "当前债务收入比可控，建议保持月供、消费贷和信用卡账单同步复盘。"
        : "债务压力偏高，先评估提前还款、延长还款节奏或降低新增负债。"
    },
    {
      title: "代际互助层",
      status: familyStatus,
      text: profile.responsibility === "critical"
        ? "多项家庭责任叠加，建议建立家庭资金池规则并明确赡养、育儿预算边界。"
        : "家庭责任相对可管理，可用年度预算表固定教育、赡养和大额支出安排。"
    },
    {
      title: "风险对冲层",
      status: hedgeStatus,
      text: profile.protection === "full"
        ? "保障结构较完整，后续重点检查保额、免赔额和家庭成员覆盖一致性。"
        : "建议先补齐家庭主要收入来源成员的医疗、意外与基础寿险保障。"
    }
  ];
}

function generateReport(profile, score) {
  const bufferPlan = getBufferPlan(profile, score);
  const actions = [];

  if (profile.emergency < 6) {
    actions.push("把每月结余的30%-50%划入独立应急金账户，目标先达到3个月刚性支出。");
  }
  if (score.debtRate > 0.3 || profile.goal === "debt") {
    actions.push("列出所有债务的利率、期限和月供，优先处理高利率与短周期压力项。");
  }
  if (profile.protection !== "full") {
    actions.push("检查家庭主要收入成员保障缺口，优先补齐医疗、意外和基础寿险。");
  }
  if (profile.goal === "education") {
    actions.push("建立教育金目标表，拆分为年度储备金额和低波动资产配置区间。");
  }
  if (profile.goal === "pension") {
    actions.push("测算退休后基础支出，区分社保养老金、商业养老和长期储蓄来源。");
  }
  if (!actions.length) {
    actions.push("保持每月一次家庭财务复盘，更新收入、支出、负债和保障变化。");
  }
  actions.push("与家庭成员共同确认本月预算边界，避免短期消费挤占长期目标。");

  return {
    summary: `当前家庭目标为“${labels.goal[profile.goal]}”，综合评分为${score.score}分，风险等级为“${score.level}”。建议先守住现金流安全底线，再推进财富积累和长期规划。`,
    bufferPlan,
    actions
  };
}

async function askAgent(message, profile) {
  if (AGENT_API_URL) {
    return fetch(AGENT_API_URL, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ message, profile })
    }).then((response) => response.json());
  }

  const text = message.toLowerCase();
  const score = state.score || calculateRisk(profile);
  const monthlyGap = Math.max(profile.income - profile.expenses - profile.debt, 0);

  if (text.includes("应急") || text.includes("现金") || text.includes("流动")) {
    const target = Math.round((profile.expenses + profile.debt) * 3);
    return `建议先把应急金建立到至少3个月刚性支出，约${target.toLocaleString()}元；更稳健的目标是6个月。你当前覆盖${profile.emergency}个月，下一步可以把每月结余中的一部分自动转入独立账户。`;
  }
  if (text.includes("房贷") || text.includes("负债") || text.includes("债务") || text.includes("月供")) {
    return `你当前债务收入比约${Math.round(score.debtRate * 100)}%。若超过35%，优先减少新增消费贷和高息负债；若低于35%，重点是保持还款稳定，并预留利率或收入波动缓冲。`;
  }
  if (text.includes("教育")) {
    return "教育金建议用目标倒推法：先估算入学年份、年度支出和已有储备，再拆成每月定投或储蓄金额。资金属性要偏稳健，避免把短期教育支出暴露在高波动资产里。";
  }
  if (text.includes("养老") || text.includes("退休")) {
    return "养老金规划可以分三层：社保养老金保底、长期储蓄补充、商业养老或稳健投资增强。建议先测算退休后基础生活费，再倒推出每年需要补足的储备。";
  }
  if (text.includes("保险") || text.includes("保障") || text.includes("疾病") || text.includes("意外")) {
    return `当前保障完整度为“${labels.protection[profile.protection]}”。家庭优先级通常是主要收入成员的医疗、意外和基础寿险，其次再考虑老人、孩子和更高保额方案。`;
  }
  if (text.includes("收益") || text.includes("股票") || text.includes("基金") || text.includes("买什么")) {
    return "我可以帮你做风险匹配、资产配置框架和产品规则解释，但不会承诺收益或直接推荐具体证券产品。先确认应急金、负债和保障，再讨论可承受波动的长期资金比例。";
  }

  return `从你的家庭画像看，当前健康分约${score.score}分，月度可调配结余约${monthlyGap.toLocaleString()}元。建议按“建档-诊断-规划-执行-跟踪”推进：先补短板，再做长期目标配置。`;
}

function statusText(status) {
  return {
    ok: "稳健",
    watch: "关注",
    risk: "预警"
  }[status];
}

function renderBufferList(targetId, items) {
  const target = document.getElementById(targetId);
  target.innerHTML = items.map((item) => `
    <article class="buffer-item">
      <div>
        <strong>${item.title}</strong>
        <p>${item.text}</p>
      </div>
      <span class="status-pill ${item.status}">${statusText(item.status)}</span>
    </article>
  `).join("");
}

function renderList(targetId, items) {
  document.getElementById(targetId).innerHTML = items.map((item) => `<li>${item}</li>`).join("");
}

function render() {
  const profile = state.profile;
  state.score = calculateRisk(profile);
  state.report = generateReport(profile, state.score);

  const score = state.score;
  const report = state.report;
  const ringDegree = Math.round(score.score / 100 * 360);

  document.getElementById("health-score").textContent = score.score;
  document.getElementById("score-ring-value").textContent = score.score;
  document.querySelector(".score-ring").style.background = `conic-gradient(var(--green) 0deg, var(--green) ${ringDegree}deg, rgba(255, 255, 255, 0.16) ${ringDegree}deg)`;

  const riskLabel = document.getElementById("risk-label");
  riskLabel.textContent = score.level;
  riskLabel.className = `risk-label ${score.tone}`;

  document.getElementById("saving-rate").textContent = `${Math.round(score.savingRate * 100)}%`;
  document.getElementById("debt-rate").textContent = `${Math.round(score.debtRate * 100)}%`;
  document.getElementById("emergency-cover").textContent = `${profile.emergency.toFixed(1)}月`;

  document.getElementById("home-locked").hidden = state.hasProfile;
  document.getElementById("home-content").hidden = !state.hasProfile;

  document.getElementById("report-locked").hidden = state.hasProfile;
  document.getElementById("report-content").hidden = !state.hasProfile;

  if (state.hasProfile) {
    renderBufferList("home-buffer-list", report.bufferPlan);
    document.getElementById("report-score").textContent = score.score;
    document.getElementById("report-summary").textContent = report.summary;
    renderList("weakness-list", score.weaknesses);
    renderBufferList("report-buffer-list", report.bufferPlan);
    renderList("report-actions", report.actions);
  }
}

function getProfileFromForm() {
  return {
    income: Number(document.getElementById("income").value) || 0,
    expenses: Number(document.getElementById("expenses").value) || 0,
    debt: Number(document.getElementById("debt").value) || 0,
    emergency: Number(document.getElementById("emergency").value) || 0,
    incomeStability: document.getElementById("income-stability").value,
    protection: document.getElementById("protection").value,
    responsibility: document.getElementById("responsibility").value,
    goal: document.getElementById("goal").value
  };
}

function switchView(viewId, options = {}) {
  if (!options.skipHistory && state.currentView && state.currentView !== viewId) {
    state.history.push(state.currentView);
  }
  state.currentView = viewId;
  document.querySelector(".app-shell").classList.toggle("is-welcome", viewId === "welcome" || viewId === "demo");
  document.querySelectorAll(".view").forEach((view) => {
    view.classList.toggle("active", view.id === viewId);
  });
  document.querySelectorAll("[data-view-target]").forEach((button) => {
    button.classList.toggle("active", button.dataset.viewTarget === viewId && button.closest(".bottom-nav"));
  });
  window.scrollTo({ top: 0, behavior: "smooth" });
}

function goBack() {
  const previousView = state.history.pop() || "welcome";
  switchView(previousView, { skipHistory: true });
}

function addMessage(role, text) {
  const message = document.createElement("div");
  message.className = `message ${role}`;
  message.textContent = text;
  const log = document.getElementById("chat-log");
  log.appendChild(message);
  log.scrollTop = log.scrollHeight;
}

function bindEvents() {
  document.getElementById("back-button").addEventListener("click", goBack);

  document.querySelectorAll("[data-view-target]").forEach((button) => {
    button.addEventListener("click", () => switchView(button.dataset.viewTarget));
  });

  document.getElementById("profile-form").addEventListener("submit", (event) => {
    event.preventDefault();
    state.profile = getProfileFromForm();
    state.hasProfile = true;
    render();
    switchView("report");
  });

  document.getElementById("chat-form").addEventListener("submit", async (event) => {
    event.preventDefault();
    const input = document.getElementById("chat-message");
    const message = input.value.trim();
    if (!message) return;
    input.value = "";
    addMessage("user", message);
    const answer = await askAgent(message, state.profile);
    addMessage("agent", typeof answer === "string" ? answer : answer.reply || "已收到，我会结合家庭画像生成建议。");
  });

  document.querySelectorAll("[data-prompt]").forEach((button) => {
    button.addEventListener("click", () => {
      document.getElementById("chat-message").value = button.dataset.prompt;
      document.getElementById("chat-form").requestSubmit();
    });
  });
}

bindEvents();
render();
addMessage("agent", "你好，我是家稳云图 AI 顾问。可以先问我应急金、房贷压力、教育金、养老金或保障缺口。");
